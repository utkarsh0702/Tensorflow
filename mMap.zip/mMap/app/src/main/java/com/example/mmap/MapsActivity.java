package com.example.mmap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final String TAG = "Mmap";
    private final double INDIA_LAT =23.242769;
    private final double INDIA_LNG =79.737854;
    private GoogleMap mMap;
    private boolean mLocationPermissionGranted;
    private FusedLocationProviderClient mLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // PERMISSION REQUIRED FUNCTION:
        initGoogleMap();



        // LIVE LOCATION BUTTON:

        ImageButton b1 = (ImageButton)findViewById(R.id.gps_btn);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCurrentLocation();
            }
        });


        // CURRENT LOCATION REQUIRED CODE:
        mLocationClient = new FusedLocationProviderClient(this);
    }

    // CURRENT LOCATION CODE:
    private void getCurrentLocation() {
        mLocationClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
            @Override
            public void onComplete(@NonNull Task<Location> task) {

                if (task.isSuccessful()) {
                    Location location = task.getResult();
                     {
                        gotoLocation( location.getLatitude(), location.getLongitude());
                    }
                } else {
                    Log.d(TAG, "getCurrentLocation Error:" + task.getException().getMessage());
                }
            }
        });
    }

    // CURRENT LOCATION RELATED CODE:
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        gotoLocation(INDIA_LAT, INDIA_LNG);
    }

    // CURRENT LOCATION RELATED CODE:
    private void gotoLocation(double lat, double lng) {
        LatLng latLng = new LatLng(lat, lng);
        mMap.addMarker(new MarkerOptions().position(latLng).title("Marker in latlng"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 14));
    }





    // PERMISSIONS REQUIRED :

    private void initGoogleMap() {
        if (isServicesOk()){
            if (isGpsEnable()) {
                if (checkLocationPermission()) {
                    Toast.makeText(this, "Ready to map", Toast.LENGTH_LONG).show();

                    SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                            .findFragmentById(R.id.map);
                    mapFragment.getMapAsync(this);

                } else {
                    requestLocationPermission();
                }
            }
        }
    }

    private boolean isGpsEnable() {

        LocationManager locationManager =(LocationManager) getSystemService(LOCATION_SERVICE);
        boolean providerEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

        if (providerEnabled){
            return true;
        }else {
            AlertDialog alertDialog = new AlertDialog.Builder(this)
                    .setTitle("GPS PERMISSIONS")
                    .setMessage("GPS IS REQUIRED")
                    .setPositiveButton("YES", (new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent i1 = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            MapsActivity.this.startActivityForResult(i1, 9003);
                        }
                    }))
                    .setCancelable(false)
                    .show();
        }

        return false;
    }

    private boolean checkLocationPermission() {

        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isServicesOk() {
        GoogleApiAvailability googleApi = GoogleApiAvailability.getInstance();
        int result = googleApi.isGooglePlayServicesAvailable(this);

        if (result == ConnectionResult.SUCCESS) {
            return true;
        } else if (googleApi.isUserResolvableError(result)) {
            Dialog dialog = googleApi.getErrorDialog(this,result,9002, new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface Task) {
                    Toast.makeText(MapsActivity.this, "Dialog is cancelled by user", Toast.LENGTH_LONG).show();
                }
            });
            dialog.show();
        }else{
            Toast.makeText(this,"Play services are requied by this application",Toast.LENGTH_LONG).show();
        }

        return false;
    }

    private void requestLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},9001);
            }
        }
    }

    public void onRequestPermissionResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);

        if (requestCode == 9001 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            mLocationPermissionGranted=true;
            Toast.makeText(this,"PERMISSION GRANTED", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this,"PERMISSION NOT GRANTED", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 9003){

            LocationManager locationManager =(LocationManager) getSystemService(LOCATION_SERVICE);
            boolean providerEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

            if (providerEnabled){
                Toast.makeText(MapsActivity.this, "GPS IS ENABLED", Toast.LENGTH_LONG).show();
            }else {
                Toast.makeText(MapsActivity.this, "GPS NOT ENABLED, UNABLE TO SHOW USER LOCATION", Toast.LENGTH_LONG).show();
            }
        }
    }


}
